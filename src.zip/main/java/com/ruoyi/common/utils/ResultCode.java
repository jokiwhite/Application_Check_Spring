package com.ruoyi.common.utils;

public interface ResultCode {

    public static Integer SUCCESS = 200;//成功

    public static Integer ERROR = 201;//失败

}
